# Domain  - Terraform Cloud & Enterprise Capabilities

The code mentioned in this document are used in the HashiCorp Certified Terraform Associate 2020 video course.


# Video-Document Mapper

| Sr No | Document Link |
| ------ | ------ |
| 1 | [Overview of Sentinel][PlDa] |
| 2 | [Overview of Remote Backends][PlDb] |





   [PlDa]: <https://github.com/zealvora/terraform-beginner-to-advanced-resource/blob/master/Terraform%20Cloud/sentinel-policy.tf>
   [PlDb]: <https://github.com/zealvora/terraform-beginner-to-advanced-resource/blob/master/Terraform%20Cloud/remote-backend.md>

