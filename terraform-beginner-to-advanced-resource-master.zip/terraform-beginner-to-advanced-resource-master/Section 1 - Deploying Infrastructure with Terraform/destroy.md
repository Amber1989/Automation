```sh
terraform destroy
terraform destroy -target aws_instance.myec2
```
